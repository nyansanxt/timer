import React, { useState } from 'react';
import { Plus, Play, Pause, RefreshCcw, X } from 'lucide-react';
import { useTimerContext } from '../context/TimerContext';

interface Timer {
  id: string;
  duration: number;
  remaining: number;
  isRunning: boolean;
  name: string;
}

export default function TimerComponent() {
  const { playSound } = useTimerContext();
  const [timers, setTimers] = useState<Timer[]>([]);
  const [hours, setHours] = useState('0');
  const [minutes, setMinutes] = useState('0');
  const [seconds, setSeconds] = useState('0');
  const [timerName, setTimerName] = useState('');

  React.useEffect(() => {
    const interval = setInterval(() => {
      setTimers((currentTimers) =>
        currentTimers.map((timer) => {
          if (!timer.isRunning) return timer;
          const newRemaining = timer.remaining - 1;
          
          if (newRemaining === 0) {
            playSound();
          }
          
          return {
            ...timer,
            remaining: Math.max(0, newRemaining),
            isRunning: newRemaining > 0,
          };
        })
      );
    }, 1000);

    return () => clearInterval(interval);
  }, [playSound]);

  const addTimer = () => {
    const totalSeconds =
      parseInt(hours) * 3600 + parseInt(minutes) * 60 + parseInt(seconds);
    if (totalSeconds <= 0) return;

    const newTimer: Timer = {
      id: Date.now().toString(),
      duration: totalSeconds,
      remaining: totalSeconds,
      isRunning: false,
      name: timerName || `タイマー ${timers.length + 1}`,
    };

    setTimers([...timers, newTimer]);
    setHours('0');
    setMinutes('0');
    setSeconds('0');
    setTimerName('');
  };

  const toggleTimer = (id: string) => {
    setTimers(
      timers.map((timer) =>
        timer.id === id ? { ...timer, isRunning: !timer.isRunning } : timer
      )
    );
  };

  const resetTimer = (id: string) => {
    setTimers(
      timers.map((timer) =>
        timer.id === id
          ? { ...timer, remaining: timer.duration, isRunning: false }
          : timer
      )
    );
  };

  const removeTimer = (id: string) => {
    setTimers(timers.filter((timer) => timer.id !== id));
  };

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h.toString().padStart(2, '0')}:${m
      .toString()
      .padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      <div className="bg-white/5 p-4 rounded-xl space-y-4">
        <div className="grid grid-cols-4 gap-4">
          <input
            type="text"
            placeholder="タイマー名"
            value={timerName}
            onChange={(e) => setTimerName(e.target.value)}
            className="col-span-4 bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
          <input
            type="number"
            min="0"
            value={hours}
            onChange={(e) => setHours(e.target.value)}
            className="bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
            placeholder="時"
          />
          <input
            type="number"
            min="0"
            max="59"
            value={minutes}
            onChange={(e) => setMinutes(e.target.value)}
            className="bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
            placeholder="分"
          />
          <input
            type="number"
            min="0"
            max="59"
            value={seconds}
            onChange={(e) => setSeconds(e.target.value)}
            className="bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
            placeholder="秒"
          />
          <button
            onClick={addTimer}
            className="bg-purple-500 hover:bg-purple-600 text-white rounded-lg px-4 py-2 flex items-center justify-center gap-2 transition-colors"
          >
            <Plus className="w-5 h-5" />
            追加
          </button>
        </div>
      </div>

      <div className="space-y-4">
        {timers.map((timer) => (
          <div
            key={timer.id}
            className="bg-white/5 p-4 rounded-xl flex items-center justify-between"
          >
            <div className="space-y-1">
              <h3 className="text-white font-medium">{timer.name}</h3>
              <p className="text-2xl font-bold text-white">
                {formatTime(timer.remaining)}
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => toggleTimer(timer.id)}
                className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
              >
                {timer.isRunning ? (
                  <Pause className="w-5 h-5" />
                ) : (
                  <Play className="w-5 h-5" />
                )}
              </button>
              <button
                onClick={() => resetTimer(timer.id)}
                className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
              >
                <RefreshCcw className="w-5 h-5" />
              </button>
              <button
                onClick={() => removeTimer(timer.id)}
                className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}