import React, { useState, useEffect } from 'react';
import { Play, Pause, RefreshCcw, Flag } from 'lucide-react';

interface Lap {
  id: number;
  time: number;
  diff: number;
}

export default function StopwatchComponent() {
  const [time, setTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [laps, setLaps] = useState<Lap[]>([]);

  useEffect(() => {
    let interval: number;
    if (isRunning) {
      interval = setInterval(() => {
        setTime((time) => time + 10);
      }, 10);
    }
    return () => clearInterval(interval);
  }, [isRunning]);

  const toggleStopwatch = () => {
    setIsRunning(!isRunning);
  };

  const resetStopwatch = () => {
    setIsRunning(false);
    setTime(0);
    setLaps([]);
  };

  const addLap = () => {
    const lastLap = laps[0]?.time || 0;
    const newLap: Lap = {
      id: Date.now(),
      time: time,
      diff: time - lastLap,
    };
    setLaps([newLap, ...laps]);
  };

  const formatTime = (ms: number) => {
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    const milliseconds = Math.floor((ms % 1000) / 10);
    return `${minutes.toString().padStart(2, '0')}:${seconds
      .toString()
      .padStart(2, '0')}.${milliseconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      <div className="bg-white/5 p-6 rounded-xl text-center">
        <div className="text-5xl font-bold text-white mb-6">
          {formatTime(time)}
        </div>
        <div className="flex justify-center gap-4">
          <button
            onClick={toggleStopwatch}
            className="p-3 rounded-lg bg-purple-500 hover:bg-purple-600 text-white transition-colors"
          >
            {isRunning ? (
              <Pause className="w-6 h-6" />
            ) : (
              <Play className="w-6 h-6" />
            )}
          </button>
          <button
            onClick={resetStopwatch}
            className="p-3 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <RefreshCcw className="w-6 h-6" />
          </button>
          <button
            onClick={addLap}
            disabled={!isRunning}
            className="p-3 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Flag className="w-6 h-6" />
          </button>
        </div>
      </div>

      {laps.length > 0 && (
        <div className="bg-white/5 p-4 rounded-xl">
          <h3 className="text-white font-medium mb-4">ラップタイム</h3>
          <div className="space-y-2">
            {laps.map((lap, index) => (
              <div
                key={lap.id}
                className="flex justify-between items-center text-white"
              >
                <span>ラップ {laps.length - index}</span>
                <div className="space-x-4">
                  <span className="text-white/60">+{formatTime(lap.diff)}</span>
                  <span>{formatTime(lap.time)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}