import React from 'react';
import { Timer, StopWatch, Clock } from 'lucide-react';
import TimerComponent from './components/TimerComponent';
import StopwatchComponent from './components/StopwatchComponent';
import { TimerProvider } from './context/TimerContext';

function App() {
  const [activeTab, setActiveTab] = React.useState<'timer' | 'stopwatch'>('timer');

  return (
    <TimerProvider>
      <div className="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-2xl mx-auto">
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl shadow-xl p-6">
              <div className="flex items-center justify-between mb-8">
                <h1 className="text-3xl font-bold text-white flex items-center gap-2">
                  <Clock className="w-8 h-8" />
                  マルチタイマー
                </h1>
                <div className="flex gap-2 bg-white/20 p-1 rounded-lg">
                  <button
                    onClick={() => setActiveTab('timer')}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                      activeTab === 'timer'
                        ? 'bg-white text-purple-600'
                        : 'text-white hover:bg-white/10'
                    }`}
                  >
                    <Timer className="w-5 h-5" />
                    タイマー
                  </button>
                  <button
                    onClick={() => setActiveTab('stopwatch')}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                      activeTab === 'stopwatch'
                        ? 'bg-white text-purple-600'
                        : 'text-white hover:bg-white/10'
                    }`}
                  >
                    <StopWatch className="w-5 h-5" />
                    ストップウォッチ
                  </button>
                </div>
              </div>

              <div className="space-y-6">
                {activeTab === 'timer' ? <TimerComponent /> : <StopwatchComponent />}
              </div>
            </div>
          </div>
        </div>
      </div>
    </TimerProvider>
  );
}

export default App;